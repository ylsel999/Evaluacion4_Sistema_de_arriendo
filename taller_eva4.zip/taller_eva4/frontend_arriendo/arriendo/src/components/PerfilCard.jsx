import {useNavigate} from 'react-router-dom';

export function PerfilCard({usuario}) {
    const navigate = useNavigate()
    return (
        <div className="container mt-5">
            <div className="card" style={{ maxWidth: '600px', margin: '0 auto' }}>
                <div className="card-header bg-primary text-white text-center">
                    <h3>Perfil de Usuario</h3>
                </div>
                <div className="card-body">
                    <ul className="list-group list-group-flush">
                        <li className="list-group-item">
                            <strong>Nombre:</strong> {usuario.nombre}
                        </li>
                        <li className="list-group-item">
                            <strong>Password:</strong> {usuario.contrasena}
                        </li>
                        <li className="list-group-item">
                            <strong>Correo Electrónico:</strong> {usuario.email}
                        </li>
                        <li className="list-group-item">
                            <strong>Teléfono:</strong> {usuario.telefono}
                        </li>
                        <li className="list-group-item">
                            <strong>Dirección:</strong> {usuario.direccion}
                        </li>
                        <li className="list-group-item">
                            <strong>Tipo de Usuario:</strong> {usuario.tipo_usuario}
                        </li>
                        <li className="list-group-item">
                            <strong>Fecha de Registro:</strong> {usuario.fecha_registro}
                        </li>
                    </ul>
                </div>
                <div className="card-footer text-center">
                    <button className="btn btn-secondary">Editar Perfil</button>
                </div>
            </div>
        </div>
    )
}
