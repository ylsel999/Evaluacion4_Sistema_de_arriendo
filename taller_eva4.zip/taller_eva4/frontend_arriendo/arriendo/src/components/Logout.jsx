import { useNavigate } from "react-router-dom";
import { handleLogout } from "./LogoutHandler";

export function Dashboard() {
    const navigate = useNavigate();

    return (
        <div>
            <h1>Panel de Usuario</h1>
            <button onClick={() => handleLogout(navigate)}>Cerrar Sesión</button>
        </div>
    );
}
