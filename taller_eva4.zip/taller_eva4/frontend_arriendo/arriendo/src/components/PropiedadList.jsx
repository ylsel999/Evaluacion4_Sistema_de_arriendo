import { useEffect, useState } from "react"
import { getAllPropiedades } from "../api/usuarios.api";
import { PropiedadCard } from "./PropiedadCard";

export function PropiedadList() {
    const [propiedades, setPropiedades ] = useState([])

    useEffect(() => {
        async function loadPropiedades() {
            const res = await getAllPropiedades();
            setPropiedades(res.data);
        }
        loadPropiedades();

    }, []);
    


    return <div>
        {propiedades.map(propiedad => (
            <PropiedadCard key={propiedad.id} propiedad={propiedad}/>
        ))}
    </div>
}