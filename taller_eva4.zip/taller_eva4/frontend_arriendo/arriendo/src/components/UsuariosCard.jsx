import {useNavigate} from 'react-router-dom';

export function UsuarioCard({usuario}) {
    const navigate = useNavigate()
    return (
        <div className="container">
        <div className="card text-center mb-3" style={{width: "18rem"}}

            onClick={() => {
                navigate('/usuarios/' + usuario.id)
            }}
        >
            <div className="container">
            <div className="card-body">
                <h5 className="card-title">{usuario.nombre}</h5>
                <p className="card-text">{usuario.email}</p>
                <p className="card-text">{usuario.tipo_usuario}</p>
                <a href="#" className="btn btn-primary">Editar usuario</a>
            </div>
            </div>
        </div>
        </div>
    )
}