import { useEffect, useState } from "react";
import { obtenerUsuario } from "../api/usuarios.api";
import { useParams } from "react-router-dom"; // Importa useParams
import { PerfilCard } from "./PerfilCard";

export function PerfilList() {
    const [usuario, setUsuario] = useState(null);
    const { id } = useParams(); // Obtén el ID de la URL

    useEffect(() => {
        async function loadUsuario() {
            try {
                const res = await obtenerUsuario(id); // Pasa el ID
                setUsuario(res.data);
            } catch (error) {
                console.error("Error al obtener el usuario:", error);
            }
        }
        if (id) loadUsuario();
    }, [id]);

    if (!usuario) return <div className="text-center mt-5">Cargando...</div>;

    return (
        <div>
            <PerfilCard usuario={usuario} />
        </div>
    );
}
