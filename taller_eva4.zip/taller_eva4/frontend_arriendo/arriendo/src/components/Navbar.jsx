import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container-fluid">
                <Link className="navbar-brand" to="/">
                    Arriendo universitarios
                </Link>
                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav ms-auto">
                        <li className="nav-item">
                            <Link className="nav-link" to="/inicio">
                                Inicio
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/usuarios-create">
                                Registro
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/usuarios">
                                Usuarios
                            </Link>
                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Perfil
                            </a>
                            <ul className="dropdown-menu">
                            <li><Link className="dropdown-item" to="/perfil">Ver perfil</Link></li>
                            <li><Link className="dropdown-item" to="/perfil/editar">Editar perfil</Link></li>
                            </ul>
                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Propiedades
                            </a>
                            <ul className="dropdown-menu">
                            <li><Link className="dropdown-item" to="/propiedades">Buscar propiedades</Link></li>
                            <li><Link className="dropdown-item" to="/propiedades-create">Crear publicacion</Link></li>
                            </ul>
                        </li>
                        <li className="nav-item">
                            <button className="btn btn-primary" onClick={() => (window.location.href = "/")}>Iniciar Sesión</button>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
