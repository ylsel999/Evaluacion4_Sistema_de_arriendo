import {useNavigate} from 'react-router-dom';

export function PropiedadCard({propiedad}) {
    const navigate = useNavigate()
    return (
        <div className='container'>
        <div className="card text-center mb-3" style={{width: "18rem"}}

            onClick={() => {
                navigate('/propiedades/' + propiedad.id)
            }}
        >
            <div className="card-body">
                <h5 className="card-title">{propiedad.direccion}</h5>
                <p className="card-text">{propiedad.descripcion}</p>
                <h7 className="card-text">{propiedad.precio}</h7>
                <hr></hr>
                <a href="#" className="btn btn-warning">Editar datos</a>
            </div>
        </div>
        </div>
    )
}