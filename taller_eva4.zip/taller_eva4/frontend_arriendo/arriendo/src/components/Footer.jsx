import React from 'react';

const Footer = () =>  {
          {/* Footer */}
          <footer className="bg-dark text-white text-center py-4">
          <p>© 2024 Arriendos. Todos los derechos reservados.</p>
          <div>
            <a href="#" className="text-white mx-2">
              Facebook
            </a>
            <a href="#" className="text-white mx-2">
              TikTok
            </a>
            <a href="#" className="text-white mx-2">
              Instagram
            </a>
          </div>
        </footer>
}

export default Footer;