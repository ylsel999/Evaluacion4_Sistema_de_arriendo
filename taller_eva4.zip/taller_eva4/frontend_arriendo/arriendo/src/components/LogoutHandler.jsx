
export function handleLogout(navigate) {
    axios.post("http://localhost:8000/api/logout/")
        .then(() => {
            localStorage.removeItem("usuario"); // Elimina el usuario del almacenamiento
            navigate("/"); // Redirige al login
        })
        .catch((err) => {
            console.error("Error al cerrar sesión:", err);
        });
}
