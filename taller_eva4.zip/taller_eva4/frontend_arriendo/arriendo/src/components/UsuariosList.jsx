import { useEffect, useState } from "react"
import { getAllUsuarios } from "../api/usuarios.api";
import { UsuarioCard } from "./UsuariosCard";

export function UsuariosList() {
    const [usuarios, setUsuarios ] = useState([])

    useEffect(() => {
        async function loadUsuarios() {
            const res = await getAllUsuarios();
            setUsuarios(res.data);
        }
        loadUsuarios();

    }, []);
    


    return <div>
        {usuarios.map(usuario => (
            <UsuarioCard key={usuario.id} usuario={usuario}/>
        ))}
    </div>
}