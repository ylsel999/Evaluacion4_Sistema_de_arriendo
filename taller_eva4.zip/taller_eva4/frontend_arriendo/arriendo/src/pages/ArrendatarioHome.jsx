import {React} from 'react';
import { UsuariosList } from "../components/UsuariosList"

export function ArrendatarioHome() {
    return (
        <div className="container">
            <h1>Hola, [arrendatario.name]</h1>
            <button className="btn btn-success mb-3">Crear publicación de arriendo</button>
            <div className="container">
                
                <UsuariosList/>
                
            </div>
        </div>
    )
}