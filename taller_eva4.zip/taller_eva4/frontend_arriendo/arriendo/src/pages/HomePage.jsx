// src/components/HomePage.js
import React from "react";

export function HomePage() {
  return (
    <div>
      {/* Hero Section */}
      <div className="container-fluid hero-section text-white text-center py-5">
        <div className="container">
          <h1 className="display-4">Encuentra o arrienda propiedades fácilmente</h1>
          <p className="lead">La plataforma que conecta arrendadores y arrendatarios en un clic.</p>
          <div>
            <button className="btn btn-primary btn-lg mx-2">Buscar Arriendos</button>
            <button className="btn btn-outline-light btn-lg mx-2">Publicar Arriendo</button>
          </div>
        </div>
      </div>

      {/* Propiedades Destacadas */}
      <div className="container py-5">
        <h2 className="text-center mb-4">Propiedades Destacadas</h2>
        <div className="row">
          {/* Ejemplo de tarjeta */}
          {[1, 2, 3].map((item) => (
            <div className="col-md-4" key={item}>
              <div className="card mb-4">
                <img
                  src={`https://via.placeholder.com/350x200`}
                  className="card-img-top"
                  alt="Propiedad"
                />
                <div className="card-body">
                  <h5 className="card-title">Propiedad {item}</h5>
                  <p className="card-text">$500.000 / mes</p>
                  <a href="#" className="btn btn-primary">
                    Ver Detalles
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>


    </div>
  );
};
