import { useEffect } from 'react';
import {useForm} from 'react-hook-form';
import { crearPropiedad, eliminarPropiedad, actualizarPropiedad, obtenerPropiedad} from '../api/usuarios.api';
import {useNavigate, useParams} from 'react-router-dom';

export function PropiedadesFormPage() {

    const {register, handleSubmit, formState: {errors}, setValue} = useForm();

    const navigate = useNavigate();
    const params = useParams();

    const onSubmit = handleSubmit(async data => {
        if (params.id) {
            await actualizarPropiedad(params.id, data)
        }else{
            await crearPropiedad(data);
        }
        navigate("/propiedades")
    });

    useEffect(() => {
        async function loadPropiedades() {
            if (params.id) {
                const res = await obtenerPropiedad(params.id);
                setValue('direccion', res.data.direccion)
                setValue('descripcion', res.data.descripcion)
                setValue('precio', res.data.precio)
                setValue('tipo', res.data.tipo)
                setValue('habitaciones', res.data.habitaciones)
                setValue('banos', res.data.banos)
            }
        }
        loadPropiedades();
    }, [])

    return (
        <div>
            <form onSubmit={onSubmit} className="container mt-5">
                <div className="mb-3">
                    <label className="form-label">Dirección</label>
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Dirección"
                        {...register('direccion', { required: true })}
                    />
                    {errors.direccion && <div className="text-danger">La dirección es requerida</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Descripción</label>
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Descripción"
                        {...register('descripcion', { required: true })}
                    />
                    {errors.descripcion && <div className="text-danger">La descripción es requerida</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Precio $</label>
                    <input
                        type="number"
                        className="form-control"
                        placeholder="Precio $"
                        {...register('precio', { required: true })}
                    />
                    {errors.precio && <div className="text-danger">El precio es requerido</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Tipo de arriendo</label>
                    <select
                        className="form-select"
                        {...register('tipo', { required: true })}
                    >
                        <option value="">Seleccione un tipo de arriendo</option>
                        <option value="casa">Casa</option>
                        <option value="departamento">Departamento</option>
                        <option value="habitacion interior">Habitación interior</option>
                    </select>
                    {errors.tipo && <div className="text-danger">El tipo de arriendo es requerido</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Número de habitaciones</label>
                    <input
                        type="number"
                        className="form-control"
                        placeholder="Número de habitaciones"
                        {...register('habitaciones', { required: true })}
                    />
                    {errors.habitaciones && <div className="text-danger">Las habitaciones son requeridas</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Número de baños</label>
                    <input
                        type="number"
                        className="form-control"
                        placeholder="Número de baños"
                        {...register('banos', { required: true })}
                    />
                    {errors.banos && <div className="text-danger">La cantidad de baños es requerida</div>}
                </div>

                <div className="d-grid">
                    <button type="submit" className="btn btn-primary">Guardar</button>
                </div>

                <hr></hr>

                <div className="d-grid">
                {params.id && <button className='btn btn-danger text-center' onClick={ async () => {
                            const aceptar = window.confirm('Estas seguro de eliminar?')
                            if (aceptar) {
                                await eliminarPropiedad(params.id);
                                navigate("/propiedades")
                            }
                        }}>Eliminar</button>}
                </div>

                <hr></hr>

                <div className="d-grid">
                {params.id && (
                    <button
                        className="btn btn-secondary text-center"
                        onClick={() => navigate(-1)} // Redirige a la página anterior
                    >
                        Cancelar
                    </button>
                )}
                </div>
            </form>
        </div>
    );
}