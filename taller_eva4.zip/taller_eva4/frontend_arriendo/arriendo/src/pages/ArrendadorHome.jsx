import {React} from "react";
import { PropiedadList } from "../components/PropiedadList"

export function ArrendadorHome() {
    return (
        <div className="container">
            <h1>Bienvenido, [Nombre del Arrendador]</h1>
            <p>Estas son las publicaciones activas de los usuarios:</p>
            <div>
                <div className="card">
                    <div className="card-body">
                        <PropiedadList/>
                    </div>
                </div>
            </div>
            <button className="btn btn-success mt-3">Añadir nueva propiedad</button>
        </div>
    );
}
