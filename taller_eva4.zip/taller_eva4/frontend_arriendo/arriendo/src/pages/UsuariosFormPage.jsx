import { useEffect } from 'react';
import {useForm} from 'react-hook-form';
import { crearUsuario, eliminarUsuario, actualizarUsuario, obtenerUsuario} from '../api/usuarios.api';
import {useNavigate, useParams} from 'react-router-dom';

export function UsuariosFormPage() {

    const {register, handleSubmit, formState: {
        errors},
        setValue
    } = useForm();

    const navigate = useNavigate();
    const params = useParams();

    const onSubmit = handleSubmit(async data => {
        if (params.id) {
            await actualizarUsuario(params.id, data)
        }else{
            await crearUsuario(data);
        }
        navigate("/usuarios")
    });

    useEffect(() => {
        async function loadUsuario() {
            if (params.id) {
                const res = await obtenerUsuario(params.id);
                setValue('email', res.data.email)
                setValue('nombre', res.data.nombre)
                setValue('password', res.data.password)
                setValue('telefono', res.data.telefono)
                setValue('direccion', res.data.direccion)
            }
        }
        loadUsuario();
    }, [])

    return (
        <div>
            <form onSubmit={onSubmit} className="container mt-5">
                <div className="mb-3">
                    <label className="form-label">Correo Electrónico</label>
                    <input
                        type="email"
                        className="form-control"
                        placeholder="Correo Electrónico"
                        {...register('email', { 
                            required: true, 
                            pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/ 
                        })}
                    />
                    {errors.email && <div className="text-danger">Debe ingresar un correo válido</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Nombre</label>
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Nombre"
                        {...register('nombre', { required: true })}
                    />
                    {errors.nombre && <div className="text-danger">El nombre es requerido</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Contraseña</label>
                    <input
                        type="password"
                        className="form-control"
                        placeholder="Contraseña"
                        {...register('password', { required: true })}
                    />
                    {errors.password && <div className="text-danger">La contraseña es requerida</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Teléfono</label>
                    <input
                        type="number"
                        className="form-control"
                        placeholder="Teléfono"
                        {...register('telefono', { required: true, pattern: /^[0-9]+$/ })}
                    />
                    {errors.telefono && <div className="text-danger">El teléfono es requerido y debe ser numérico</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Dirección</label>
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Dirección"
                        {...register('direccion', { required: true })}
                    />
                    {errors.direccion && <div className="text-danger">La dirección es requerida</div>}
                </div>

                <div className="mb-3">
                    <label className="form-label">Tipo de Usuario</label>
                    <select
                        className="form-select"
                        {...register('tipo_usuario', { required: true })}
                    >
                        <option value="">Seleccione un tipo de usuario</option>
                        <option value="administrador">Administrador</option>
                        <option value="arrendador">Arrendador</option>
                        <option value="arrendatario">Arrendatario</option>
                    </select>
                    {errors.tipo_usuario && <div className="text-danger">El tipo de usuario es requerido</div>}
                </div>


                <div className="d-grid">
                    <button type="submit" className="btn btn-primary">Guardar</button>
                </div>
                <hr></hr>
                <div className="d-grid">
                    {params.id && <button className='btn btn-danger' onClick={ async () => {
                        const aceptar = window.confirm('Estas seguro de eliminar?')
                        if (aceptar) {
                            await eliminarUsuario(params.id);
                            navigate("/usuarios")
                        }
                    }}>Eliminar</button>}
                </div>

                <hr></hr>

                <div className="d-grid">
                {params.id && (
                    <button
                        className="btn btn-secondary text-center"
                        onClick={() => navigate(-1)} // Redirige a la página anterior
                    >
                        Cancelar
                    </button>
                )}
                </div>
            </form>
        </div>
    );
}