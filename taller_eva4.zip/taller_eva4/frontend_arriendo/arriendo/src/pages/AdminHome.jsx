import {React} from "react";

export function AdminHome() {
    return (
        <div className="container text-center">
            <h1>Bienvenido, Administrador {usuario?.nombre}</h1>
            <p>Tu rol: {usuario?.tipo_usuario}</p>
            <div>
                <p>Propiedades totales: 120</p>
                <p>Arrendadores: 45 | Arrendatarios: 75</p>
                <p>Publicaciones activas: 90</p>
            </div>
            <div class="row">
            <div className="col">
                <button type="button" className="btn btn-outline-info">Gestionar Propiedades</button>
            </div>
            <div className="col">
                <button type="button" className="btn btn-outline-success">Gestionar Usuarios</button>
            </div>
            </div>

            <button className="btn btn-danger" onClick={logout}>Cerrar Sesión</button>

        </div>
    );
}
