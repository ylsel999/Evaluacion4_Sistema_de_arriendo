import { UsuariosList } from "../components/UsuariosList"

export function UsuariosPage(params) {
    return <UsuariosList/>;
}