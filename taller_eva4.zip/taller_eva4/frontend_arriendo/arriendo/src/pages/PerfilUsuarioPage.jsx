import { PerfilList } from "../components/ObtenerPerfil"

export function PerfilPage(params) {
    return <PerfilList/>;
}