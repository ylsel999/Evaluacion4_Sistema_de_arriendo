import { PropiedadList } from "../components/PropiedadList"

export function PropiedadPage(params) {
    return <PropiedadList/>;
}