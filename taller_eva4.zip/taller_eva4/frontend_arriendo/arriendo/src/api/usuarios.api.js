import axios from 'axios';

const arriendoApi = axios.create({
    baseURL: "http://127.0.0.1:8000/arriendo/api/"
});

export const getAllUsuarios = () => {
    return arriendoApi.get("/usuarios/");
}

export const obtenerUsuario = (id) => {
    return arriendoApi.get(`/usuarios/${id}/`);
}

export const crearUsuario = (usuario) => {
    return arriendoApi.post("/usuarios/", usuario);
}

export const eliminarUsuario = (id) => {
    return arriendoApi.delete(`/usuarios/${id}/`)
}

export const actualizarUsuario = (id, usuario) => {
    return arriendoApi.put(`/usuarios/${id}/`, usuario)
}

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

export const getAllPropiedades = () => {
    return arriendoApi.get("/propiedades/");
}

export const obtenerPropiedad = (id) => {
    return arriendoApi.get(`/propiedades/${id}/`);
}

export const crearPropiedad = (propiedad) => {
    return arriendoApi.post("/propiedades/", propiedad);
}

export const eliminarPropiedad = (id) => {
    return arriendoApi.delete(`/propiedades/${id}/`)
}

export const actualizarPropiedad = (id, propiedad) => {
    return arriendoApi.put(`/propiedades/${id}/`, propiedad)
}

//---------------------------------------------------------------------------

