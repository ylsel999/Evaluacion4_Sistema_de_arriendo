import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { UsuariosPage } from './pages/UsuariosPage';
import { UsuariosFormPage } from './pages/UsuariosFormPage';
import Navbar from './components/Navbar';
import { PerfilPage } from './pages/PerfilUsuarioPage';
import { PropiedadPage } from './pages/PropiedadPage';
import { PropiedadesFormPage } from './pages/PropiedadFormPage';
import { AdminHome } from './pages/AdminHome';
import { ArrendadorHome } from './pages/ArrendadorHome';
import { ArrendatarioHome } from './pages/ArrendatarioHome';
import { LoginPage } from './pages/LoginPage';
import { ProtectedRoute } from "./components/ProtectedRoute";
import {HomePage} from './pages/HomePage'
import Footer from './components/Footer';

function App() {
    return (
        <BrowserRouter>
            <Navbar />
            <Routes>
                {/* Rutas públicas */}
                <Route path="/" element={<LoginPage />} />
                <Route path="/usuarios-create"element={<UsuariosFormPage />}/>
                <Route path='/inicio' element={<HomePage />} />

                {/* Rutas protegidas para usuarios autenticados */}
                <Route
                    path="/usuarios"
                    element={
                        //<ProtectedRoute>
                            <UsuariosPage />
                        //</ProtectedRoute>
                    }
                />
                
                <Route
                    path="/usuarios/:id"
                    element={
                        //<ProtectedRoute>
                            <UsuariosFormPage />
                        //</ProtectedRoute>
                    }
                />
                <Route
                    path="/perfil/:id"
                    element={
                        //<ProtectedRoute>
                            <PerfilPage />
                        //</ProtectedRoute>
                    }
                />
                <Route
                    path="/propiedades"
                    element={
                        //<ProtectedRoute>
                            <PropiedadPage />
                        //</ProtectedRoute>
                    }
                />
                <Route
                    path="/propiedades-create"
                    element={
                        //<ProtectedRoute>
                            <PropiedadesFormPage />
                        //</ProtectedRoute>
                    }
                />
                <Route
                    path="/propiedades/:id"
                    element={
                        //<ProtectedRoute>
                            <PropiedadesFormPage />
                        //</ProtectedRoute>
                    }
                />

                {/* Rutas específicas por rol */}
                <Route
                    path="/admin"
                    element={
                        //<ProtectedRoute role="administrador">
                            <AdminHome />
                        //</ProtectedRoute>
                    }
                />
                <Route
                    path="/arrendador"
                    element={
                        //<ProtectedRoute role="arrendador">
                            <ArrendadorHome />
                        //</ProtectedRoute>
                    }
                />
                <Route
                    path="/arrendatario"
                    element={
                        //<ProtectedRoute role="arrendatario">
                            <ArrendatarioHome />
                        //</ProtectedRoute>
                    }
                />
            </Routes>
            
            <Footer />
        </BrowserRouter>
    );
}

export default App;
