from rest_framework import routers
from django.urls import path
from .api import UsuarioViewSet, PropiedadViewSet
from .views import login_usuario, logout_usuario


router = routers.DefaultRouter()

router.register('arriendo/api/usuarios', UsuarioViewSet, 'usuarios')

router.register('arriendo/api/propiedades', PropiedadViewSet, 'reservas')

urlpatterns = router.urls + [
    path('api/login/', login_usuario, name='login_usuario'),
    path('api/logout/', logout_usuario, name='logout_usuario'),
]


# router.register('arriendo/api/arrendadores', ArrendadorViewSet, 'habitaciones')
# router.register('arriendo/api/arrendatarios', ArrendatarioViewSet, 'servicios')