from .models import Usuario, Propiedad
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework import viewsets, permissions
from .serializers import UsuarioSerializer, PropiedadSerializer

class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = Usuario.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = UsuarioSerializer



class PropiedadViewSet(viewsets.ModelViewSet):
    queryset = Propiedad.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = PropiedadSerializer


# class ArrendadorViewSet(viewsets.ModelViewSet):
#     queryset = Arrendador.objects.all()
#     permission_classes = [permissions.AllowAny]
#     serializer_class = ArrendadorSerializer

# class ArrendatarioViewSet(viewsets.ModelViewSet):
#     queryset = Arrendatario.objects.all()
#     permission_classes = [permissions.AllowAny]
#     serializer_class = ArrendatarioSerializer