from django.contrib.auth import authenticate
from django.http import JsonResponse
from rest_framework.decorators import api_view
from django.contrib.auth import logout

@api_view(['POST'])
def login_usuario(request):
    email = request.data.get('email')
    password = request.data.get('password')

    # Verifica que los datos sean válidos
    if not email or not password:
        return JsonResponse({'error': 'Email y contraseña son requeridos'}, status=400)

    # Autentica al usuario
    user = authenticate(username=email, password=password)
    if user is not None:
        return JsonResponse({
            'id': user.id,
            'nombre': user.nombre,
            'email': user.email,
            'tipo_usuario': user.tipo_usuario,
        })
    else:
        return JsonResponse({'error': 'Credenciales inválidas'}, status=400)

@api_view(['POST'])
def logout_usuario(request):
    logout(request)  # Cierra la sesión del usuario
    return JsonResponse({'message': 'Sesión cerrada correctamente'}, status=200)