from rest_framework import serializers
from .models import Usuario, Propiedad
from django.contrib.auth.models import User

class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = [
            'email',
            'nombre',
            'telefono',
            'direccion',
            'tipo_usuario',
            'fecha_registro',
        ]
        extra_kwargs = {
            'password': {'write_only': True}  # Opcional, si decides incluir el manejo de contraseñas
        }

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        usuario = Usuario.objects.create(**validated_data)
        if password:
            usuario.set_password(password)
            usuario.save()
        return usuario

class PropiedadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Propiedad
        fields = ('id', 'direccion', 'descripcion', 'precio', 'tipo', 'habitaciones', 'banos',)
