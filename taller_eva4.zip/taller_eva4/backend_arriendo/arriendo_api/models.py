from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.db import models

class UsuarioManager(BaseUserManager):
    def create_user(self, email, nombre, password=None, **extra_fields):
        """Crea y guarda un usuario común."""
        if not email:
            raise ValueError("El email es obligatorio.")
        email = self.normalize_email(email)
        user = self.model(email=email, nombre=nombre, **extra_fields)
        user.set_password(password)  # Encripta la contraseña
        user.save(using=self._db)
        return user

    def create_superuser(self, email, nombre, password=None, **extra_fields):
        """Crea y guarda un superusuario."""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if not extra_fields.get('is_staff'):
            raise ValueError("El superusuario debe tener is_staff=True.")
        if not extra_fields.get('is_superuser'):
            raise ValueError("El superusuario debe tener is_superuser=True.")

        return self.create_user(email, nombre, password, **extra_fields)


class Usuario(AbstractBaseUser):
    email = models.EmailField(unique=True)
    nombre = models.CharField(max_length=255)
    telefono = models.CharField(max_length=20, blank=True)
    direccion = models.TextField(blank=True)
    tipo_usuario = models.CharField(max_length=20, choices=[
        ('administrador', 'Administrador'),
        ('arrendador', 'Arrendador'),
        ('arrendatario', 'Arrendatario'),
    ])
    fecha_registro = models.DateTimeField(auto_now_add=True)

    # Campos adicionales requeridos por Django
    is_active = models.BooleanField(default=True)  # Si el usuario está activo
    is_staff = models.BooleanField(default=False)  # Permite acceso al panel admin
    is_superuser = models.BooleanField(default=False)  # Superusuario

    # Vinculación del gestor personalizado
    objects = UsuarioManager()

    # Campo que se usará como identificador único
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['nombre']  # Campos requeridos al crear un superusuario

    def __str__(self):
        return self.nombre

    class Meta:
        db_table = 'usuario'
        verbose_name = "Usuario"
        verbose_name_plural = "Usuarios"


class Propiedad(models.Model):
    direccion = models.CharField(max_length=255)
    descripcion = models.TextField()
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    tipo = models.CharField(max_length=50, choices=[('casa', 'Casa'), ('departamento', 'Departamento'), ('habitacion interior', 'Habitacion interior')])
    habitaciones = models.IntegerField()
    banos = models.IntegerField()
    
    def __str__(self):
        return f"Propiedad en {self.direccion}"
    
    class Meta:
        db_table='propiedad'
        verbose_name="Propiedad"
        verbose_name_plural="Propiedades"


# class Arrendatario(models.Model):
#     usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE)
#     fecha_nacimiento = models.DateField()

#     def __str__(self):
#         return f"{self.usuario.nombre}"
    
#     class Meta:
#         db_table='arrendatario'
#         verbose_name="Arrendatario"
#         verbose_name_plural="Arrendatarios"

# class Arrendador(models.Model):
#     usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE)
#     fecha_nacimiento = models.DateField()

#     def __str__(self):
#         return f"{self.usuario.nombre}"
    
#     class Meta:
#         db_table='arrendador'
#         verbose_name="Arrendador"
#         verbose_name_plural="Arrendadores"
